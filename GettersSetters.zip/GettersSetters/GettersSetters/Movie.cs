﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GettersSetters
{
    class Movie
    {
        public string title;
        public string director;
        private string rating;

        public Movie(string aTitle, string aDirector, string aRating)
        {
            title = aTitle;
            director = aDirector;
            Rating = aRating; //instead of the small rating we pass the setters and getters in order to access 
        }

        //properties to modify getters and setters
        public string Rating {

                get { return rating; }
                set {
                    if (value == "G" || value == "PG" || value == "PG-13" || value == "R")
                    {
                        rating = value;
                    }
                    else {
                        rating = "NR";
                    }
                }

        }
    }
}
